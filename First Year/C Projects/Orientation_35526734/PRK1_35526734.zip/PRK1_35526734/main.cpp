#include <iostream>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

int main()
{

    cout<<"This program was written by: Niel Nortier (35526734)" << endl;
    cout<<endl;

    cout<<"Square"<<endl;
    cout<<endl;

    cout << "*******************" << endl;
    cout << "*******************" << endl;
    cout << "*******************" << endl;
    cout << "*******************" << endl;
    cout << "*******************" << endl;
    cout << "*******************" << endl;
    cout << "*******************" << endl;
    cout << "*******************" << endl;
    cout << "*******************" << endl;
    cout << "*******************" << endl;

    cout << endl;
    cout <<"Diamond"<<endl;
    cout << endl;

    cout << "       *" << endl;
    cout << "      ***" << endl;
    cout << "     *****" << endl;
    cout << "    *******" << endl;
    cout << "   *********" << endl;
    cout << "  ***********" << endl;
    cout << " *************" << endl;
    cout << "***************" << endl;
    cout << " *************" << endl;
    cout << "  ***********" << endl;
    cout << "   *********" << endl;
    cout << "    *******" << endl;
    cout << "     *****" << endl;
    cout << "      ***" << endl;
    cout << "       *" << endl;

    cout << endl;
    cout <<"Triangle"<<endl;
    cout << endl;

    cout<<"*"<<endl;
    cout<<"**"<<endl;
    cout<<"***"<<endl;
    cout<<"****"<<endl;
    cout<<"*****"<<endl;
    cout<<"******"<<endl;
    cout<<"*******"<<endl;
    cout<<"********"<<endl;
    cout<<"*********"<<endl;
    cout<<"**********"<<endl;
    cout<<"***********"<<endl;
    cout<<"**********"<<endl;
    cout<<"*********"<<endl;
    cout<<"********"<<endl;
    cout<<"*******"<<endl;
    cout<<"******"<<endl;
    cout<<"*****"<<endl;
    cout<<"****"<<endl;
    cout<<"***"<<endl;
    cout<<"**"<<endl;
    cout<<"*"<<endl;

    cout<<endl;
    cout<<"Heart"<<endl;
    cout << endl;

    cout<<"  *****     *****"<<endl;
    cout<<" *******   *******"<<endl;
    cout<<"********* *********"<<endl;
    cout<<"*******************"<<endl;
    cout<<" *****************"<<endl;
    cout<<"  ***************"<<endl;
    cout<<"   *************"<<endl;
    cout<<"    ***********"<<endl;
    cout<<"     *********"<<endl;
    cout<<"      *******"<<endl;
    cout<<"       *****"<<endl;
    cout<<"        ***"<<endl;
    cout<<"         *"<<endl;

    return 0;
}
