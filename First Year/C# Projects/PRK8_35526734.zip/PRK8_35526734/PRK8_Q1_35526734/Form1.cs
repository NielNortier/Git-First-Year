﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


//Niel Nortier 35526734

namespace PRK8_Q1_35526734
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            StreamWriter TextOut;                       //Variables
            Random rand = new Random();
            int iNum,iTotal;



            if(int.TryParse(tbNum.Text, out iNum))                  //Input
            {
                iNum = int.Parse(tbNum.Text);
                iTotal = 0;


                TextOut = File.CreateText("RandomNumbers.txt");


                for (int i = 0; i <= iNum; i++)                                             //Textfile processing
                {
                    int TxtVal = rand.Next(100);
                    TextOut.WriteLine(TxtVal.ToString());
                    iTotal += TxtVal;
                }
                TextOut.WriteLine("The number of random values read from file: " + tbNum.Text);
                TextOut.WriteLine("The total of the numbers is: " + iTotal.ToString());

                TextOut.Close();


                MessageBox.Show("File Saved Successfully");
                btnRead.Enabled = true;

            }
            else
            {
                MessageBox.Show("Invalid Data Type");
            }
        }

        private void btnReload_Click(object sender, EventArgs e)            //output to listbox
        {
            StreamReader ReadFile;
            lbOut.Items.Clear();

            ReadFile = File.OpenText("RandomNumbers.txt");

            while (!ReadFile.EndOfStream)
            {
                lbOut.Items.Add(ReadFile.ReadLine());
            }

            ReadFile.Close();

        }
    }
}
