﻿//Niel Nortier 35526734 PRK2_Q2
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK2_Q2_35526734
{
    
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            //Calculation
            double dCharge, dTip, dTax, dTotal;
             dCharge = double.Parse(txtCharge.Text);
            dTip = dCharge * 0.15;
            dTax = (dCharge* 0.07);
            dTotal = dCharge + dTip + dTax;
            //Output
            Console.WriteLine(dTax);
            lblTip.Text = "Tip: R"+dTip.ToString();
            lblTax.Text = "Tax: R" + dTax.ToString();
            lblTotal.Text = "Total: R" + dTotal.ToString();


        }
    }
}
