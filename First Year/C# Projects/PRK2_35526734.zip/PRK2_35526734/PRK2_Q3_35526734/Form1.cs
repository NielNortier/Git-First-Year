﻿//Niel Nortier PRK2 Q3  35526734
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK2_Q3_35526734
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            //Variable Population

            double dGross,dNet,dTax,dDeduct,dOther;
            dGross = double.Parse(txtGross.Text);
            dDeduct = double.Parse(txtStandardDeduction.Text);
            dOther = double.Parse(txtOtherExemptions.Text);

            //Calculation

            dNet = dGross - (dDeduct + dOther);
            dTax = dNet * 0.15;

            //Output

            lblGross.Text = "Gross Income: R" +dGross.ToString();
            lblNet.Text = "Net Income: R" + dNet.ToString();
            lblTax.Text = "Tax payable: R" + dTax.ToString();


            

        }

        private void lblGrossIncome_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
