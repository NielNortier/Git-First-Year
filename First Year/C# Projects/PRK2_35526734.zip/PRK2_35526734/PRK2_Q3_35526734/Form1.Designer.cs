﻿namespace PRK2_Q3_35526734
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblGrossIncome = new System.Windows.Forms.Label();
            this.txtGross = new System.Windows.Forms.TextBox();
            this.lblGross = new System.Windows.Forms.Label();
            this.lblNet = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.btnCal = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblStandard = new System.Windows.Forms.Label();
            this.txtStandardDeduction = new System.Windows.Forms.TextBox();
            this.lblOtherExemptions = new System.Windows.Forms.Label();
            this.txtOtherExemptions = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblGrossIncome
            // 
            this.lblGrossIncome.AutoSize = true;
            this.lblGrossIncome.Location = new System.Drawing.Point(51, 33);
            this.lblGrossIncome.Name = "lblGrossIncome";
            this.lblGrossIncome.Size = new System.Drawing.Size(100, 13);
            this.lblGrossIncome.TabIndex = 0;
            this.lblGrossIncome.Text = "Enter Gross Income";
            this.lblGrossIncome.Click += new System.EventHandler(this.lblGrossIncome_Click);
            // 
            // txtGross
            // 
            this.txtGross.Location = new System.Drawing.Point(54, 49);
            this.txtGross.Name = "txtGross";
            this.txtGross.Size = new System.Drawing.Size(100, 20);
            this.txtGross.TabIndex = 1;
            // 
            // lblGross
            // 
            this.lblGross.AutoSize = true;
            this.lblGross.Location = new System.Drawing.Point(51, 286);
            this.lblGross.Name = "lblGross";
            this.lblGross.Size = new System.Drawing.Size(86, 13);
            this.lblGross.TabIndex = 2;
            this.lblGross.Text = "Gross Income: R";
            // 
            // lblNet
            // 
            this.lblNet.AutoSize = true;
            this.lblNet.Location = new System.Drawing.Point(51, 262);
            this.lblNet.Name = "lblNet";
            this.lblNet.Size = new System.Drawing.Size(76, 13);
            this.lblNet.TabIndex = 2;
            this.lblNet.Text = "Net Income: R";
            // 
            // lblTax
            // 
            this.lblTax.AutoSize = true;
            this.lblTax.Location = new System.Drawing.Point(51, 238);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(80, 13);
            this.lblTax.TabIndex = 2;
            this.lblTax.Text = "Tax Payable: R";
            // 
            // btnCal
            // 
            this.btnCal.Location = new System.Drawing.Point(54, 197);
            this.btnCal.Name = "btnCal";
            this.btnCal.Size = new System.Drawing.Size(100, 23);
            this.btnCal.TabIndex = 3;
            this.btnCal.Text = "Calculate";
            this.btnCal.UseVisualStyleBackColor = true;
            this.btnCal.Click += new System.EventHandler(this.btnCal_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 0;
            this.label1.Click += new System.EventHandler(this.lblGrossIncome_Click);
            // 
            // lblStandard
            // 
            this.lblStandard.AutoSize = true;
            this.lblStandard.Location = new System.Drawing.Point(51, 86);
            this.lblStandard.Name = "lblStandard";
            this.lblStandard.Size = new System.Drawing.Size(130, 13);
            this.lblStandard.TabIndex = 0;
            this.lblStandard.Text = "Enter Standard Deduction";
            this.lblStandard.Click += new System.EventHandler(this.lblGrossIncome_Click);
            // 
            // txtStandardDeduction
            // 
            this.txtStandardDeduction.Location = new System.Drawing.Point(54, 102);
            this.txtStandardDeduction.Name = "txtStandardDeduction";
            this.txtStandardDeduction.Size = new System.Drawing.Size(100, 20);
            this.txtStandardDeduction.TabIndex = 1;
            this.txtStandardDeduction.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblOtherExemptions
            // 
            this.lblOtherExemptions.AutoSize = true;
            this.lblOtherExemptions.Location = new System.Drawing.Point(51, 137);
            this.lblOtherExemptions.Name = "lblOtherExemptions";
            this.lblOtherExemptions.Size = new System.Drawing.Size(118, 13);
            this.lblOtherExemptions.TabIndex = 0;
            this.lblOtherExemptions.Text = "Enter Other Exemptions";
            this.lblOtherExemptions.Click += new System.EventHandler(this.lblGrossIncome_Click);
            // 
            // txtOtherExemptions
            // 
            this.txtOtherExemptions.Location = new System.Drawing.Point(54, 153);
            this.txtOtherExemptions.Name = "txtOtherExemptions";
            this.txtOtherExemptions.Size = new System.Drawing.Size(100, 20);
            this.txtOtherExemptions.TabIndex = 1;
            this.txtOtherExemptions.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(268, 353);
            this.Controls.Add(this.btnCal);
            this.Controls.Add(this.lblTax);
            this.Controls.Add(this.lblNet);
            this.Controls.Add(this.lblGross);
            this.Controls.Add(this.txtOtherExemptions);
            this.Controls.Add(this.txtStandardDeduction);
            this.Controls.Add(this.txtGross);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblOtherExemptions);
            this.Controls.Add(this.lblStandard);
            this.Controls.Add(this.lblGrossIncome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblGrossIncome;
        private System.Windows.Forms.TextBox txtGross;
        private System.Windows.Forms.Label lblGross;
        private System.Windows.Forms.Label lblNet;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Button btnCal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblStandard;
        private System.Windows.Forms.TextBox txtStandardDeduction;
        private System.Windows.Forms.Label lblOtherExemptions;
        private System.Windows.Forms.TextBox txtOtherExemptions;
    }
}

