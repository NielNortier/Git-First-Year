﻿namespace PRK2_35526734
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtName = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.txtAge = new System.Windows.Forms.TextBox();
            this.txtStandard = new System.Windows.Forms.TextBox();
            this.txtSchool = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.lblStandard = new System.Windows.Forms.Label();
            this.lblSchool = new System.Windows.Forms.Label();
            this.lblOutput = new System.Windows.Forms.Label();
            this.btnName = new System.Windows.Forms.Button();
            this.btnNameAge = new System.Windows.Forms.Button();
            this.btnNameStandard = new System.Windows.Forms.Button();
            this.btnNameSchool = new System.Windows.Forms.Button();
            this.btnNameAgeStandard = new System.Windows.Forms.Button();
            this.btnNameAgeStandardSchool = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(116, 66);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(178, 20);
            this.txtName.TabIndex = 0;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(116, 123);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(178, 20);
            this.txtAge.TabIndex = 0;
            // 
            // txtStandard
            // 
            this.txtStandard.Location = new System.Drawing.Point(116, 177);
            this.txtStandard.Name = "txtStandard";
            this.txtStandard.Size = new System.Drawing.Size(178, 20);
            this.txtStandard.TabIndex = 0;
            // 
            // txtSchool
            // 
            this.txtSchool.Location = new System.Drawing.Point(116, 234);
            this.txtSchool.Name = "txtSchool";
            this.txtSchool.Size = new System.Drawing.Size(178, 20);
            this.txtSchool.TabIndex = 0;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(113, 50);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Name";
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(113, 107);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(26, 13);
            this.lblAge.TabIndex = 2;
            this.lblAge.Text = "Age";
            // 
            // lblStandard
            // 
            this.lblStandard.AutoSize = true;
            this.lblStandard.Location = new System.Drawing.Point(113, 161);
            this.lblStandard.Name = "lblStandard";
            this.lblStandard.Size = new System.Drawing.Size(50, 13);
            this.lblStandard.TabIndex = 2;
            this.lblStandard.Text = "Standard";
            // 
            // lblSchool
            // 
            this.lblSchool.AutoSize = true;
            this.lblSchool.Location = new System.Drawing.Point(113, 218);
            this.lblSchool.Name = "lblSchool";
            this.lblSchool.Size = new System.Drawing.Size(40, 13);
            this.lblSchool.TabIndex = 2;
            this.lblSchool.Text = "School";
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.Location = new System.Drawing.Point(113, 275);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(0, 13);
            this.lblOutput.TabIndex = 3;
            // 
            // btnName
            // 
            this.btnName.Location = new System.Drawing.Point(116, 314);
            this.btnName.Name = "btnName";
            this.btnName.Size = new System.Drawing.Size(178, 23);
            this.btnName.TabIndex = 4;
            this.btnName.Text = "Name";
            this.btnName.UseVisualStyleBackColor = true;
            this.btnName.Click += new System.EventHandler(this.btnName_Click);
            // 
            // btnNameAge
            // 
            this.btnNameAge.Location = new System.Drawing.Point(116, 343);
            this.btnNameAge.Name = "btnNameAge";
            this.btnNameAge.Size = new System.Drawing.Size(178, 23);
            this.btnNameAge.TabIndex = 4;
            this.btnNameAge.Text = "Name and Age";
            this.btnNameAge.UseVisualStyleBackColor = true;
            this.btnNameAge.Click += new System.EventHandler(this.btnNameAge_Click);
            // 
            // btnNameStandard
            // 
            this.btnNameStandard.Location = new System.Drawing.Point(116, 372);
            this.btnNameStandard.Name = "btnNameStandard";
            this.btnNameStandard.Size = new System.Drawing.Size(178, 23);
            this.btnNameStandard.TabIndex = 4;
            this.btnNameStandard.Text = "Name and Standard";
            this.btnNameStandard.UseVisualStyleBackColor = true;
            this.btnNameStandard.Click += new System.EventHandler(this.btnNameStandard_Click);
            // 
            // btnNameSchool
            // 
            this.btnNameSchool.Location = new System.Drawing.Point(116, 401);
            this.btnNameSchool.Name = "btnNameSchool";
            this.btnNameSchool.Size = new System.Drawing.Size(178, 23);
            this.btnNameSchool.TabIndex = 4;
            this.btnNameSchool.Text = "Name and School";
            this.btnNameSchool.UseVisualStyleBackColor = true;
            this.btnNameSchool.Click += new System.EventHandler(this.btnNameSchool_Click);
            // 
            // btnNameAgeStandard
            // 
            this.btnNameAgeStandard.Location = new System.Drawing.Point(116, 430);
            this.btnNameAgeStandard.Name = "btnNameAgeStandard";
            this.btnNameAgeStandard.Size = new System.Drawing.Size(178, 23);
            this.btnNameAgeStandard.TabIndex = 4;
            this.btnNameAgeStandard.Text = "Name, Age and Standard";
            this.btnNameAgeStandard.UseVisualStyleBackColor = true;
            this.btnNameAgeStandard.Click += new System.EventHandler(this.btnNameAgeStandard_Click);
            // 
            // btnNameAgeStandardSchool
            // 
            this.btnNameAgeStandardSchool.Location = new System.Drawing.Point(116, 459);
            this.btnNameAgeStandardSchool.Name = "btnNameAgeStandardSchool";
            this.btnNameAgeStandardSchool.Size = new System.Drawing.Size(178, 23);
            this.btnNameAgeStandardSchool.TabIndex = 4;
            this.btnNameAgeStandardSchool.Text = "Name, Age, Standard and School";
            this.btnNameAgeStandardSchool.UseVisualStyleBackColor = true;
            this.btnNameAgeStandardSchool.Click += new System.EventHandler(this.btnNameAgeStandardSchool_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 541);
            this.Controls.Add(this.btnNameAgeStandardSchool);
            this.Controls.Add(this.btnNameAgeStandard);
            this.Controls.Add(this.btnNameSchool);
            this.Controls.Add(this.btnNameStandard);
            this.Controls.Add(this.btnNameAge);
            this.Controls.Add(this.btnName);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.lblSchool);
            this.Controls.Add(this.lblStandard);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtSchool);
            this.Controls.Add(this.txtStandard);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.txtName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.TextBox txtStandard;
        private System.Windows.Forms.TextBox txtSchool;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblStandard;
        private System.Windows.Forms.Label lblSchool;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.Button btnName;
        private System.Windows.Forms.Button btnNameAge;
        private System.Windows.Forms.Button btnNameStandard;
        private System.Windows.Forms.Button btnNameSchool;
        private System.Windows.Forms.Button btnNameAgeStandard;
        private System.Windows.Forms.Button btnNameAgeStandardSchool;
    }
}

