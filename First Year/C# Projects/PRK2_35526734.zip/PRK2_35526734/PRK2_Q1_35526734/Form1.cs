﻿// Niel Nortier 35526734 PRK2 Q1
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PRK2_35526734
{
    public partial class Form1 : Form
    {
        string sName, sSchool;
        int iAge, iStandard;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnNameAge_Click(object sender, EventArgs e)
        {
            //Name and Age
            UserData();
            lblOutput.Text = sName + " is " + iAge.ToString() + " Years old";

        }

        private void btnNameStandard_Click(object sender, EventArgs e)
        {
            //Name and Standard
            UserData();
            lblOutput.Text = sName + " is in Standard " + iStandard.ToString();
        }

        private void btnNameSchool_Click(object sender, EventArgs e)
        {
            //Name and School
            UserData();
            lblOutput.Text = sName + " goes to " + sSchool + ", School";

        }

        private void btnNameAgeStandard_Click(object sender, EventArgs e)
        {
            //Name, Age and Standard
            UserData();
            lblOutput.Text = sName + ", " + iAge.ToString() + " years, Standard " + iStandard.ToString(); 
        }

        private void btnNameAgeStandardSchool_Click(object sender, EventArgs e)
        {
            //Name, Age, Standard and School
            UserData();
            lblOutput.Text = sName + ", " + iAge.ToString() + " years, Standard " + iStandard.ToString() + ", from " + sSchool;
        }

        private void UserData() //method to reduce multiple code
        {
            sName = txtName.Text;
            iAge = Convert.ToInt32(txtAge.Text);
            sSchool = txtSchool.Text;
            iStandard = Convert.ToInt32(txtStandard.Text);



        }
        private void btnName_Click(object sender, EventArgs e)
        {
            //Name
            UserData();
            lblOutput.Text = sName;

        }
    }
}
