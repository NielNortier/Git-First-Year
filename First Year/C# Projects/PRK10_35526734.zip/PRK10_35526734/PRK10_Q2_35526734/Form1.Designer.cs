﻿namespace PRK10_Q2_35526734
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbNames = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbRounds = new System.Windows.Forms.TextBox();
            this.cbDifficulty = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbOut = new System.Windows.Forms.ListBox();
            this.cbFriend = new System.Windows.Forms.CheckBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.sdFile = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // tbNames
            // 
            this.tbNames.Location = new System.Drawing.Point(429, 25);
            this.tbNames.Name = "tbNames";
            this.tbNames.Size = new System.Drawing.Size(121, 20);
            this.tbNames.TabIndex = 1;
            this.tbNames.TextChanged += new System.EventHandler(this.tbMarks_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(62, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Enter Name and Surname";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(62, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rounds Survived";
            // 
            // tbRounds
            // 
            this.tbRounds.Location = new System.Drawing.Point(429, 72);
            this.tbRounds.Name = "tbRounds";
            this.tbRounds.Size = new System.Drawing.Size(121, 20);
            this.tbRounds.TabIndex = 1;
            this.tbRounds.TextChanged += new System.EventHandler(this.tbMarks_TextChanged);
            // 
            // cbDifficulty
            // 
            this.cbDifficulty.FormattingEnabled = true;
            this.cbDifficulty.Items.AddRange(new object[] {
            "Easy(x3)",
            "Medium(x5)",
            "Hard(x10)"});
            this.cbDifficulty.Location = new System.Drawing.Point(429, 121);
            this.cbDifficulty.Name = "cbDifficulty";
            this.cbDifficulty.Size = new System.Drawing.Size(121, 21);
            this.cbDifficulty.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(62, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Difficulty Played On";
            // 
            // lbOut
            // 
            this.lbOut.FormattingEnabled = true;
            this.lbOut.Location = new System.Drawing.Point(65, 272);
            this.lbOut.Name = "lbOut";
            this.lbOut.Size = new System.Drawing.Size(485, 173);
            this.lbOut.TabIndex = 3;
            // 
            // cbFriend
            // 
            this.cbFriend.AutoSize = true;
            this.cbFriend.Location = new System.Drawing.Point(429, 183);
            this.cbFriend.Name = "cbFriend";
            this.cbFriend.Size = new System.Drawing.Size(138, 17);
            this.cbFriend.TabIndex = 4;
            this.cbFriend.Text = "Did You Bring a Friend?";
            this.cbFriend.UseVisualStyleBackColor = true;
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(65, 183);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(135, 23);
            this.btnCalc.TabIndex = 5;
            this.btnCalc.Text = "Add Player Earnings";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(253, 183);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(135, 23);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Add Player Earnings";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.BtnSace_Click);
            // 
            // Form1
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.Grip;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(758, 511);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.cbFriend);
            this.Controls.Add(this.lbOut);
            this.Controls.Add(this.cbDifficulty);
            this.Controls.Add(this.tbRounds);
            this.Controls.Add(this.tbNames);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Name = "Form1";
            this.Text = "Hostel Room Shootings";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tbNames;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbRounds;
        private System.Windows.Forms.ComboBox cbDifficulty;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lbOut;
        private System.Windows.Forms.CheckBox cbFriend;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.SaveFileDialog sdFile;
    }
}

