﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK10_Q2_35526734
{
    
    public partial class Form1 : Form
    {
        const int ROUNDMONEY = 20;
        int iPlayer = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void tbMarks_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void CheckRoom(int iShoot, int iRoom)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            iPlayer += 1;

            double dEarnings = 0;
            RoundsCalc(int.Parse(tbRounds.Text), ref dEarnings);
            dEarnings =  dEarnings * DiffMultiplier();

            lbOut.Items.Add(iPlayer.ToString() + ".  " + tbNames.Text + " Has Survived " + tbRounds.Text + " With a difficulty Multiplier of x" + DiffMultiplier() + " Thus Earning him " + dEarnings.ToString("c"));
            OutputClear();

            
        }

        private void OutputClear()
        {
            tbNames.Text = "";
            tbRounds.Text = "";
            cbDifficulty.SelectedIndex = 0;
            cbFriend.Checked = false;
            lbOut.Items.Add("");
        } 

        private void RoundsCalc(int iRounds, ref double dMoney)
        {
            dMoney = iRounds * ROUNDMONEY;

            if (cbFriend.Checked)
            {
                dMoney = dMoney + 20;
            }
        }

        private int DiffMultiplier()
        {

            int DiffMultiplies = 0;
            switch (cbDifficulty.SelectedIndex)
            {
                case 0: 
                    DiffMultiplies = 3;
                    break;
                    
                case 1:
                    DiffMultiplies = 5;
                    break;

                case 2:
                    DiffMultiplies = 10;
                    break;


            }
            return DiffMultiplies;
            
        }

        private bool InviteCheck()
        {
            if (int.Parse(tbRounds.Text) > 100)
            {
                return true;
            }
            else return false;
        }

        private void BtnSace_Click(object sender, EventArgs e)
        {
            StreamWriter outputFile;
            try
            {
                if(sdFile.ShowDialog() == DialogResult.OK){
                    string path = sdFile.FileName;

                    outputFile = File.CreateText(path);

                    outputFile.WriteLine(lbOut);

                }

            }
            catch(IOException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
