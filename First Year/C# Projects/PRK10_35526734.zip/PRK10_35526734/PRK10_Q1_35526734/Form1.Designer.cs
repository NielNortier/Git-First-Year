﻿namespace PRK10_Q1_35526734
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.lbOut = new System.Windows.Forms.ListBox();
            this.tbDays = new System.Windows.Forms.TextBox();
            this.tbRes = new System.Windows.Forms.TextBox();
            this.tbSpa = new System.Windows.Forms.TextBox();
            this.tbCar = new System.Windows.Forms.TextBox();
            this.tbMed = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "No. of Days Stayed";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Restuarant Charges includingg VAT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(169, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Spa and Health Treatment Charge";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(47, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Charges for Car Rental";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(47, 214);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Medication and Rehabilitation Bill";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(50, 319);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 38);
            this.button1.TabIndex = 1;
            this.button1.Text = "Calculate Total Charge";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(329, 319);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(123, 38);
            this.button2.TabIndex = 1;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lbOut
            // 
            this.lbOut.FormattingEnabled = true;
            this.lbOut.Location = new System.Drawing.Point(50, 384);
            this.lbOut.Name = "lbOut";
            this.lbOut.Size = new System.Drawing.Size(402, 134);
            this.lbOut.TabIndex = 2;
            // 
            // tbDays
            // 
            this.tbDays.Location = new System.Drawing.Point(319, 50);
            this.tbDays.Name = "tbDays";
            this.tbDays.Size = new System.Drawing.Size(100, 20);
            this.tbDays.TabIndex = 3;
            // 
            // tbRes
            // 
            this.tbRes.Location = new System.Drawing.Point(319, 83);
            this.tbRes.Name = "tbRes";
            this.tbRes.Size = new System.Drawing.Size(100, 20);
            this.tbRes.TabIndex = 3;
            // 
            // tbSpa
            // 
            this.tbSpa.Location = new System.Drawing.Point(319, 126);
            this.tbSpa.Name = "tbSpa";
            this.tbSpa.Size = new System.Drawing.Size(100, 20);
            this.tbSpa.TabIndex = 3;
            // 
            // tbCar
            // 
            this.tbCar.Location = new System.Drawing.Point(319, 167);
            this.tbCar.Name = "tbCar";
            this.tbCar.Size = new System.Drawing.Size(100, 20);
            this.tbCar.TabIndex = 3;
            // 
            // tbMed
            // 
            this.tbMed.Location = new System.Drawing.Point(319, 207);
            this.tbMed.Name = "tbMed";
            this.tbMed.Size = new System.Drawing.Size(100, 20);
            this.tbMed.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 601);
            this.Controls.Add(this.tbMed);
            this.Controls.Add(this.tbCar);
            this.Controls.Add(this.tbSpa);
            this.Controls.Add(this.tbRes);
            this.Controls.Add(this.tbDays);
            this.Controls.Add(this.lbOut);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = " Resort Charges";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListBox lbOut;
        private System.Windows.Forms.TextBox tbDays;
        private System.Windows.Forms.TextBox tbRes;
        private System.Windows.Forms.TextBox tbSpa;
        private System.Windows.Forms.TextBox tbCar;
        private System.Windows.Forms.TextBox tbMed;
    }
}

