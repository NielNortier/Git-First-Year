﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Niel Nortier PRK10_35526734



namespace PRK10_Q1_35526734
{
    public partial class Form1 : Form
    {

        const double DAILYFEE = 550.00;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lbOut.Items.Add("Stay charges: " + (CalcStayCharge(double.Parse(tbDays.Text))).ToString("c"));
            lbOut.Items.Add ("Miscellaneous charges: " + (CalcMiscCharges(double.Parse(tbRes.Text), double.Parse(tbSpa.Text), double.Parse(tbCar.Text), double.Parse(tbMed.Text))).ToString("c"));
            lbOut.Items.Add("Total Bill: " + CalcTotalCharges((CalcStayCharge(double.Parse(tbDays.Text))), (CalcMiscCharges(double.Parse(tbRes.Text), double.Parse(tbSpa.Text), double.Parse(tbCar.Text), double.Parse(tbMed.Text)))).ToString("c"));

        }

        public double CalcStayCharge(double dDays)
        {
            Double dTotal = dDays * DAILYFEE;
            return dTotal;
        }

        public double CalcMiscCharges(double dRes,double dSpa, double dCar, double dMed)
        {
            double dTotal = dRes + dSpa + dCar + dMed;
            return dTotal;
        }

        public double CalcTotalCharges(double dStayCharge, double dMiscCharge)
        {
           double  dTotal = dStayCharge + dMiscCharge;
            return dTotal;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
