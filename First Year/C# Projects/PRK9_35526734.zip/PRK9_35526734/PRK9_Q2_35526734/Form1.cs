﻿//Niel Nortier 35526734;


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK9_Q2_35526734
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double dBudget;

            if(double.TryParse(tbBudget.Text, out  dBudget))
            {
                dBudget = double.Parse(tbBudget.Text);
            }

           DisplaySlip(PriceChecker(),dBudget);
             

           
        }

        public bool GamingCheck()
        {
            if((rbCPU_G.Checked) && (rbGPU_G.Checked) && (rbRAM32.Checked) && (rbMB_G.Checked))
            {
                    return true;
            }else return false;
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            lbOUT.Items.Add("Build your own PC.");
            lbOUT.Items.Add("");
            lbOUT.Items.Add("If all components of the PC is Gaming parts you will recieve a 10% discount");
            lbOUT.Items.Add("");
            lbOUT.Items.Add("PC Part Prices");
            lbOUT.Items.Add("Gaming CPU:\t\t R9000");
            lbOUT.Items.Add("Gaming CPU:\t\t R9000");
            lbOUT.Items.Add("Gaming GPU:\t\t R12000");
            lbOUT.Items.Add("Budget GPU:\t\t R5000");
            lbOUT.Items.Add("8gb RAM:\t\t R5000");
            lbOUT.Items.Add("16gb RAM:\t\t R9000");
            lbOUT.Items.Add("32gb RAM:\t\t R17000");
            lbOUT.Items.Add("Gaming Motherboard:\t R12000");
            lbOUT.Items.Add("Budget Motherboad:\t R7000");
        }

        private void DisplaySlip(double dTotal,double dBudged)
        {
            lbOUT.Items.Add("");

            lbOUT.Items.Add("This is The parts you choosed for your program: ");
            if (rbCPU_G.Checked)
            {
                lbOUT.Items.Add("Gaming CPU:\t\t R9000");
            }
             if (rbCPU_B.Checked)
            {
                lbOUT.Items.Add("Gaming CPU:\t\t R9000");
            }
             if (rbGPU_G.Checked)
            {
                lbOUT.Items.Add("Gaming GPU:\t\t R12000");
            }
             if (rbGPU_B.Checked)
            {
                lbOUT.Items.Add("Budget GPU:\t\t R5000");
            }
             if (rbRAM8.Checked)
            {
                lbOUT.Items.Add("8gb RAM:\t\t R5000");
            }
             if (rbRAM16.Checked)
            {
                lbOUT.Items.Add("16gb RAM:\t\t R9000");
            }
             if (rbRAM32.Checked)
            {
                lbOUT.Items.Add("32gb RAM:\t\t R17000");
            }
             if (rbMB_G.Checked)
            {
                lbOUT.Items.Add("Gaming Motherboard:\t R12000");
            }
             if (rbMB_B.Checked)
            {
                lbOUT.Items.Add("Budget Motherboad:\t R7000");
            }

            if (GamingCheck())
            {
                dTotal = dTotal * 0.20;
            }
            lbOUT.Items.Add("Your total cost for the PC will be: " + dTotal.ToString());
        }
        
        public double PriceChecker()
        {
            double Total = 0;
            if (rbCPU_G.Checked)
            {
                Total += 9000.00;
            } else if (rbCPU_B.Checked)
            {
                Total += 4000.00;
            }
            else if (rbGPU_G.Checked)
            {
                Total += 12000.00;
            }
            else if (rbGPU_B.Checked)
            {
                Total += 5000.00;
            }
            else if (rbRAM8.Checked)
            {
                Total += 5000.00;
            }
            else if (rbRAM16.Checked)
            {
                Total += 9000.00;
            }
            else if (rbRAM32.Checked)
            {
                Total += 17000.00;
            }
            else if (rbMB_G.Checked)
            {
                Total += 12000.00;
            }
            else if (rbMB_B.Checked)
            {
                Total += 7000.00;
            }

            return Total;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
