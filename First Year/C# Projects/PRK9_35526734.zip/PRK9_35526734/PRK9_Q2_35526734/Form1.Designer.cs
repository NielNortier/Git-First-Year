﻿namespace PRK9_Q2_35526734
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbCPU_B = new System.Windows.Forms.RadioButton();
            this.gbCPU = new System.Windows.Forms.GroupBox();
            this.rbCPU_G = new System.Windows.Forms.RadioButton();
            this.gbGPU = new System.Windows.Forms.GroupBox();
            this.rbGPU_G = new System.Windows.Forms.RadioButton();
            this.rbGPU_B = new System.Windows.Forms.RadioButton();
            this.gbRAM = new System.Windows.Forms.GroupBox();
            this.rbRAM8 = new System.Windows.Forms.RadioButton();
            this.rbRAM16 = new System.Windows.Forms.RadioButton();
            this.rbRAM32 = new System.Windows.Forms.RadioButton();
            this.gbMB = new System.Windows.Forms.GroupBox();
            this.rbMB_G = new System.Windows.Forms.RadioButton();
            this.rbMB_B = new System.Windows.Forms.RadioButton();
            this.lbOUT = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbBudget = new System.Windows.Forms.TextBox();
            this.gbCPU.SuspendLayout();
            this.gbGPU.SuspendLayout();
            this.gbRAM.SuspendLayout();
            this.gbMB.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbCPU_B
            // 
            this.rbCPU_B.AutoSize = true;
            this.rbCPU_B.Location = new System.Drawing.Point(6, 42);
            this.rbCPU_B.Name = "rbCPU_B";
            this.rbCPU_B.Size = new System.Drawing.Size(84, 17);
            this.rbCPU_B.TabIndex = 1;
            this.rbCPU_B.TabStop = true;
            this.rbCPU_B.Text = "Budget CPU";
            this.rbCPU_B.UseVisualStyleBackColor = true;
            // 
            // gbCPU
            // 
            this.gbCPU.Controls.Add(this.rbCPU_G);
            this.gbCPU.Controls.Add(this.rbCPU_B);
            this.gbCPU.Location = new System.Drawing.Point(67, 123);
            this.gbCPU.Name = "gbCPU";
            this.gbCPU.Size = new System.Drawing.Size(149, 78);
            this.gbCPU.TabIndex = 2;
            this.gbCPU.TabStop = false;
            this.gbCPU.Text = "Choose your CPU";
            // 
            // rbCPU_G
            // 
            this.rbCPU_G.AutoSize = true;
            this.rbCPU_G.Location = new System.Drawing.Point(6, 19);
            this.rbCPU_G.Name = "rbCPU_G";
            this.rbCPU_G.Size = new System.Drawing.Size(86, 17);
            this.rbCPU_G.TabIndex = 1;
            this.rbCPU_G.TabStop = true;
            this.rbCPU_G.Text = "Gaming CPU";
            this.rbCPU_G.UseVisualStyleBackColor = true;
            // 
            // gbGPU
            // 
            this.gbGPU.Controls.Add(this.rbGPU_G);
            this.gbGPU.Controls.Add(this.rbGPU_B);
            this.gbGPU.Location = new System.Drawing.Point(67, 237);
            this.gbGPU.Name = "gbGPU";
            this.gbGPU.Size = new System.Drawing.Size(149, 78);
            this.gbGPU.TabIndex = 2;
            this.gbGPU.TabStop = false;
            this.gbGPU.Text = "Choose your GPU";
            // 
            // rbGPU_G
            // 
            this.rbGPU_G.AutoSize = true;
            this.rbGPU_G.Location = new System.Drawing.Point(6, 19);
            this.rbGPU_G.Name = "rbGPU_G";
            this.rbGPU_G.Size = new System.Drawing.Size(87, 17);
            this.rbGPU_G.TabIndex = 1;
            this.rbGPU_G.TabStop = true;
            this.rbGPU_G.Text = "Gaming GPU";
            this.rbGPU_G.UseVisualStyleBackColor = true;
            // 
            // rbGPU_B
            // 
            this.rbGPU_B.AutoSize = true;
            this.rbGPU_B.Location = new System.Drawing.Point(6, 42);
            this.rbGPU_B.Name = "rbGPU_B";
            this.rbGPU_B.Size = new System.Drawing.Size(85, 17);
            this.rbGPU_B.TabIndex = 1;
            this.rbGPU_B.TabStop = true;
            this.rbGPU_B.Text = "Budget GPU";
            this.rbGPU_B.UseVisualStyleBackColor = true;
            // 
            // gbRAM
            // 
            this.gbRAM.Controls.Add(this.rbRAM8);
            this.gbRAM.Controls.Add(this.rbRAM32);
            this.gbRAM.Controls.Add(this.rbRAM16);
            this.gbRAM.Location = new System.Drawing.Point(252, 119);
            this.gbRAM.Name = "gbRAM";
            this.gbRAM.Size = new System.Drawing.Size(156, 112);
            this.gbRAM.TabIndex = 2;
            this.gbRAM.TabStop = false;
            this.gbRAM.Text = "RAM Amount";
            // 
            // rbRAM8
            // 
            this.rbRAM8.AutoSize = true;
            this.rbRAM8.Location = new System.Drawing.Point(6, 19);
            this.rbRAM8.Name = "rbRAM8";
            this.rbRAM8.Size = new System.Drawing.Size(70, 17);
            this.rbRAM8.TabIndex = 1;
            this.rbRAM8.TabStop = true;
            this.rbRAM8.Text = "8gb RAM";
            this.rbRAM8.UseVisualStyleBackColor = true;
            // 
            // rbRAM16
            // 
            this.rbRAM16.AutoSize = true;
            this.rbRAM16.Location = new System.Drawing.Point(6, 42);
            this.rbRAM16.Name = "rbRAM16";
            this.rbRAM16.Size = new System.Drawing.Size(76, 17);
            this.rbRAM16.TabIndex = 1;
            this.rbRAM16.TabStop = true;
            this.rbRAM16.Text = "16gb RAM";
            this.rbRAM16.UseVisualStyleBackColor = true;
            // 
            // rbRAM32
            // 
            this.rbRAM32.AutoSize = true;
            this.rbRAM32.Location = new System.Drawing.Point(6, 65);
            this.rbRAM32.Name = "rbRAM32";
            this.rbRAM32.Size = new System.Drawing.Size(121, 17);
            this.rbRAM32.TabIndex = 1;
            this.rbRAM32.TabStop = true;
            this.rbRAM32.Text = "32gb RAM (Gaming)";
            this.rbRAM32.UseVisualStyleBackColor = true;
            // 
            // gbMB
            // 
            this.gbMB.Controls.Add(this.rbMB_G);
            this.gbMB.Controls.Add(this.rbMB_B);
            this.gbMB.Location = new System.Drawing.Point(246, 237);
            this.gbMB.Name = "gbMB";
            this.gbMB.Size = new System.Drawing.Size(149, 78);
            this.gbMB.TabIndex = 2;
            this.gbMB.TabStop = false;
            this.gbMB.Text = "Motherboard";
            // 
            // rbMB_G
            // 
            this.rbMB_G.AutoSize = true;
            this.rbMB_G.Location = new System.Drawing.Point(6, 19);
            this.rbMB_G.Name = "rbMB_G";
            this.rbMB_G.Size = new System.Drawing.Size(124, 17);
            this.rbMB_G.TabIndex = 1;
            this.rbMB_G.TabStop = true;
            this.rbMB_G.Text = "Gaming Motherboard";
            this.rbMB_G.UseVisualStyleBackColor = true;
            // 
            // rbMB_B
            // 
            this.rbMB_B.AutoSize = true;
            this.rbMB_B.Location = new System.Drawing.Point(6, 42);
            this.rbMB_B.Name = "rbMB_B";
            this.rbMB_B.Size = new System.Drawing.Size(125, 17);
            this.rbMB_B.TabIndex = 1;
            this.rbMB_B.TabStop = true;
            this.rbMB_B.Text = "Budged Motherboard";
            this.rbMB_B.UseVisualStyleBackColor = true;
            // 
            // lbOUT
            // 
            this.lbOUT.FormattingEnabled = true;
            this.lbOUT.Location = new System.Drawing.Point(474, 89);
            this.lbOUT.Name = "lbOUT";
            this.lbOUT.Size = new System.Drawing.Size(293, 329);
            this.lbOUT.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(72, 348);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Calculate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(234, 348);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "What is your budged?";
            // 
            // tbBudget
            // 
            this.tbBudget.Location = new System.Drawing.Point(197, 41);
            this.tbBudget.Name = "tbBudget";
            this.tbBudget.Size = new System.Drawing.Size(100, 20);
            this.tbBudget.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbBudget);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbOUT);
            this.Controls.Add(this.gbRAM);
            this.Controls.Add(this.gbMB);
            this.Controls.Add(this.gbGPU);
            this.Controls.Add(this.gbCPU);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.gbCPU.ResumeLayout(false);
            this.gbCPU.PerformLayout();
            this.gbGPU.ResumeLayout(false);
            this.gbGPU.PerformLayout();
            this.gbRAM.ResumeLayout(false);
            this.gbRAM.PerformLayout();
            this.gbMB.ResumeLayout(false);
            this.gbMB.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RadioButton rbCPU_B;
        private System.Windows.Forms.GroupBox gbCPU;
        private System.Windows.Forms.RadioButton rbCPU_G;
        private System.Windows.Forms.GroupBox gbGPU;
        private System.Windows.Forms.RadioButton rbGPU_G;
        private System.Windows.Forms.RadioButton rbGPU_B;
        private System.Windows.Forms.GroupBox gbRAM;
        private System.Windows.Forms.RadioButton rbRAM8;
        private System.Windows.Forms.RadioButton rbRAM32;
        private System.Windows.Forms.RadioButton rbRAM16;
        private System.Windows.Forms.GroupBox gbMB;
        private System.Windows.Forms.RadioButton rbMB_G;
        private System.Windows.Forms.RadioButton rbMB_B;
        private System.Windows.Forms.ListBox lbOUT;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbBudget;
    }
}

