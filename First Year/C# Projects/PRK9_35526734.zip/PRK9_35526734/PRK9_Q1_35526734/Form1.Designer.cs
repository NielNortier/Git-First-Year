﻿namespace PRK9_Q2_35526734
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRev = new System.Windows.Forms.Label();
            this.lblCom = new System.Windows.Forms.Label();
            this.lblEarned = new System.Windows.Forms.Label();
            this.btnCal = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.tbRev = new System.Windows.Forms.TextBox();
            this.tbCom = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblRev
            // 
            this.lblRev.AutoSize = true;
            this.lblRev.Location = new System.Drawing.Point(143, 102);
            this.lblRev.Name = "lblRev";
            this.lblRev.Size = new System.Drawing.Size(79, 13);
            this.lblRev.TabIndex = 0;
            this.lblRev.Text = "Revenue sale: ";
            // 
            // lblCom
            // 
            this.lblCom.AutoSize = true;
            this.lblCom.Location = new System.Drawing.Point(134, 149);
            this.lblCom.Name = "lblCom";
            this.lblCom.Size = new System.Drawing.Size(126, 13);
            this.lblCom.TabIndex = 0;
            this.lblCom.Text = "Commission Percentage: ";
            // 
            // lblEarned
            // 
            this.lblEarned.AutoSize = true;
            this.lblEarned.Location = new System.Drawing.Point(134, 191);
            this.lblEarned.Name = "lblEarned";
            this.lblEarned.Size = new System.Drawing.Size(100, 13);
            this.lblEarned.TabIndex = 0;
            this.lblEarned.Text = "Earned Commision: ";
            // 
            // btnCal
            // 
            this.btnCal.Location = new System.Drawing.Point(137, 238);
            this.btnCal.Name = "btnCal";
            this.btnCal.Size = new System.Drawing.Size(75, 23);
            this.btnCal.TabIndex = 1;
            this.btnCal.Text = "Calculate";
            this.btnCal.UseVisualStyleBackColor = true;
            this.btnCal.Click += new System.EventHandler(this.btnCal_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(277, 238);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // tbRev
            // 
            this.tbRev.Location = new System.Drawing.Point(317, 102);
            this.tbRev.Name = "tbRev";
            this.tbRev.Size = new System.Drawing.Size(100, 20);
            this.tbRev.TabIndex = 2;
            this.tbRev.TextChanged += new System.EventHandler(this.tbRev_TextChanged);
            // 
            // tbCom
            // 
            this.tbCom.Location = new System.Drawing.Point(317, 146);
            this.tbCom.Name = "tbCom";
            this.tbCom.Size = new System.Drawing.Size(100, 20);
            this.tbCom.TabIndex = 2;
            this.tbCom.TextChanged += new System.EventHandler(this.tbRev_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbCom);
            this.Controls.Add(this.tbRev);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCal);
            this.Controls.Add(this.lblEarned);
            this.Controls.Add(this.lblCom);
            this.Controls.Add(this.lblRev);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRev;
        private System.Windows.Forms.Label lblCom;
        private System.Windows.Forms.Label lblEarned;
        private System.Windows.Forms.Button btnCal;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox tbRev;
        private System.Windows.Forms.TextBox tbCom;
    }
}

