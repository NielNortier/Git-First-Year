﻿//Niel Nortier 35526734

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK9_Q2_35526734
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tbRev_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            CalculateDisplayCommision(int.Parse(tbRev.Text), int.Parse(tbCom.Text));
        }

        private void CalculateDisplayCommision(int iRevenue, int iPercentage)
        {
            int iTotal;
            iTotal = iRevenue * (iPercentage / 100);

            lblEarned.Text = "Earned Commission: " + iTotal.ToString(); 
        }
    }
}
