﻿namespace PRK5_Q2_35526734
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbPizza = new System.Windows.Forms.GroupBox();
            this.lblName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.rbHawaiian = new System.Windows.Forms.RadioButton();
            this.rbPepperoni = new System.Windows.Forms.RadioButton();
            this.cbSpeed = new System.Windows.Forms.CheckBox();
            this.lbOut = new System.Windows.Forms.ListBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTip = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblDonation = new System.Windows.Forms.Label();
            this.txtCharity = new System.Windows.Forms.TextBox();
            this.nuAmount = new System.Windows.Forms.NumericUpDown();
            this.gbPizza.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nuAmount)).BeginInit();
            this.SuspendLayout();
            // 
            // gbPizza
            // 
            this.gbPizza.Controls.Add(this.nuAmount);
            this.gbPizza.Controls.Add(this.txtCharity);
            this.gbPizza.Controls.Add(this.txtTip);
            this.gbPizza.Controls.Add(this.txtNumber);
            this.gbPizza.Controls.Add(this.txtName);
            this.gbPizza.Controls.Add(this.cbSpeed);
            this.gbPizza.Controls.Add(this.rbPepperoni);
            this.gbPizza.Controls.Add(this.rbHawaiian);
            this.gbPizza.Controls.Add(this.lblDonation);
            this.gbPizza.Controls.Add(this.label2);
            this.gbPizza.Controls.Add(this.label1);
            this.gbPizza.Controls.Add(this.lblName);
            this.gbPizza.Location = new System.Drawing.Point(12, 12);
            this.gbPizza.Name = "gbPizza";
            this.gbPizza.Size = new System.Drawing.Size(372, 304);
            this.gbPizza.TabIndex = 0;
            this.gbPizza.TabStop = false;
            this.gbPizza.Text = "Order One Pizza";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(6, 16);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(104, 13);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Name and Surname:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Contact Number: ";
            // 
            // rbHawaiian
            // 
            this.rbHawaiian.AutoSize = true;
            this.rbHawaiian.Location = new System.Drawing.Point(6, 71);
            this.rbHawaiian.Name = "rbHawaiian";
            this.rbHawaiian.Size = new System.Drawing.Size(69, 17);
            this.rbHawaiian.TabIndex = 2;
            this.rbHawaiian.Text = "Hawaiian";
            this.rbHawaiian.UseVisualStyleBackColor = true;
            // 
            // rbPepperoni
            // 
            this.rbPepperoni.AutoSize = true;
            this.rbPepperoni.Location = new System.Drawing.Point(6, 94);
            this.rbPepperoni.Name = "rbPepperoni";
            this.rbPepperoni.Size = new System.Drawing.Size(73, 17);
            this.rbPepperoni.TabIndex = 2;
            this.rbPepperoni.Text = "Pepperoni";
            this.rbPepperoni.UseVisualStyleBackColor = true;
            // 
            // cbSpeed
            // 
            this.cbSpeed.AutoSize = true;
            this.cbSpeed.Location = new System.Drawing.Point(117, 231);
            this.cbSpeed.Name = "cbSpeed";
            this.cbSpeed.Size = new System.Drawing.Size(103, 17);
            this.cbSpeed.TabIndex = 3;
            this.cbSpeed.Text = "Speedy Delivery";
            this.cbSpeed.UseVisualStyleBackColor = true;
            // 
            // lbOut
            // 
            this.lbOut.FormattingEnabled = true;
            this.lbOut.Location = new System.Drawing.Point(390, 28);
            this.lbOut.Name = "lbOut";
            this.lbOut.Size = new System.Drawing.Size(328, 277);
            this.lbOut.TabIndex = 1;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(117, 16);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 4;
            // 
            // txtNumber
            // 
            this.txtNumber.Location = new System.Drawing.Point(117, 35);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(100, 20);
            this.txtNumber.TabIndex = 4;
            this.txtNumber.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tip for Driver: R";
            // 
            // txtTip
            // 
            this.txtTip.Location = new System.Drawing.Point(117, 178);
            this.txtTip.Name = "txtTip";
            this.txtTip.Size = new System.Drawing.Size(100, 20);
            this.txtTip.TabIndex = 4;
            this.txtTip.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 322);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(372, 50);
            this.button1.TabIndex = 2;
            this.button1.Text = "Calculate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblDonation
            // 
            this.lblDonation.AutoSize = true;
            this.lblDonation.Location = new System.Drawing.Point(0, 208);
            this.lblDonation.Name = "lblDonation";
            this.lblDonation.Size = new System.Drawing.Size(111, 13);
            this.lblDonation.TabIndex = 1;
            this.lblDonation.Text = "Donation to Charity: R";
            // 
            // txtCharity
            // 
            this.txtCharity.Location = new System.Drawing.Point(117, 205);
            this.txtCharity.Name = "txtCharity";
            this.txtCharity.Size = new System.Drawing.Size(100, 20);
            this.txtCharity.TabIndex = 4;
            this.txtCharity.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // nuAmount
            // 
            this.nuAmount.Location = new System.Drawing.Point(227, 82);
            this.nuAmount.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nuAmount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nuAmount.Name = "nuAmount";
            this.nuAmount.Size = new System.Drawing.Size(57, 20);
            this.nuAmount.TabIndex = 5;
            this.nuAmount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbOut);
            this.Controls.Add(this.gbPizza);
            this.Name = "Form1";
            this.Text = "Form1";
            this.gbPizza.ResumeLayout(false);
            this.gbPizza.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nuAmount)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbPizza;
        private System.Windows.Forms.TextBox txtNumber;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.CheckBox cbSpeed;
        private System.Windows.Forms.RadioButton rbPepperoni;
        private System.Windows.Forms.RadioButton rbHawaiian;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.ListBox lbOut;
        private System.Windows.Forms.TextBox txtTip;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtCharity;
        private System.Windows.Forms.Label lblDonation;
        private System.Windows.Forms.NumericUpDown nuAmount;
    }
}

