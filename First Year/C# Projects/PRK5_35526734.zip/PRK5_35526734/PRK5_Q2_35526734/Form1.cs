﻿using System;
//Niel Nortier 35526734
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK5_Q2_35526734
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sName, sNumber;
            bool bFlag;
            double dCharity, dTip, dTotal = 0.00 ;
            const double DELIVERYFEE = 60;

            bFlag = cbSpeed.Checked;
            sName = txtName.Text;
            sNumber = txtNumber.Text;

            if ((double.TryParse(txtCharity.Text, out dCharity)))
            {
                dCharity = double.Parse(txtCharity.Text);

            }
            else MessageBox.Show("Invalid Donation Entry");

            if (double.TryParse(txtTip.Text, out dTip))
            {
                dTip = double.Parse(txtTip.Text);
            }
            else MessageBox.Show("Invalid Tip Entry");


            //output

            lbOut.Items.Add("Name of client: " + sName);
            lbOut.Items.Add("Contact Details " + sNumber);
            if (bFlag)
            {
                lbOut.Items.Add("Speedy Delivery activated");
                dTotal += 30;
            }
            else lbOut.Items.Add("Speedy Delivery not activated");

            switch (nuAmount.Value)
            {
                case 1 :
                    if (rbHawaiian.Checked)
                    {
                        dTotal += 50;
                        lbOut.Items.Add("1 Hawaiian Pizzas");
                    } else { lbOut.Items.Add("1 Hawaiian Pepperoni");
                        dTotal += 50;
                    }
                    break;

                case 2 :
                    if (rbHawaiian.Checked)
                    {
                        lbOut.Items.Add("2 Hawaiian Pizzas");
                        dTotal += 70;
                    }
                    else { lbOut.Items.Add(" Hawaiian Pepperoni");
                        dTotal += 70;
                    }
                    break;

                case 3:
                    if (rbHawaiian.Checked)
                    {
                        lbOut.Items.Add("3 Hawaiian Pizzas");
                        dTotal += 100;
                    }
                    else { lbOut.Items.Add("3 Hawaiian Pepperoni");
                        dTotal += 100;
                    }
                    break;

                case 4:
                    if (rbHawaiian.Checked)
                    {
                        lbOut.Items.Add("4 Hawaiian Pizzas");
                        dTotal += 130;
                    }
                    else { lbOut.Items.Add("4 Hawaiian Pepperoni");
                        dTotal += 130;
                    }
                    break;

                
            }
            dTotal += DELIVERYFEE + dCharity + dTip;

            lbOut.Items.Add("Total: R" + dTotal.ToString());



        }
    }
}
