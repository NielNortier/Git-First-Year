﻿namespace PRK5_Q1_35526734
{
    partial class frmMix
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rb1Red = new System.Windows.Forms.RadioButton();
            this.rb1Blue = new System.Windows.Forms.RadioButton();
            this.rb1Yellow = new System.Windows.Forms.RadioButton();
            this.rb2Red = new System.Windows.Forms.RadioButton();
            this.rb2Blue = new System.Windows.Forms.RadioButton();
            this.rb2Yellow = new System.Windows.Forms.RadioButton();
            this.btnMix = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rb1Yellow);
            this.groupBox1.Controls.Add(this.rb1Blue);
            this.groupBox1.Controls.Add(this.rb1Red);
            this.groupBox1.Location = new System.Drawing.Point(21, 75);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(229, 147);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select The First Color";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rb2Yellow);
            this.groupBox2.Controls.Add(this.rb2Blue);
            this.groupBox2.Controls.Add(this.rb2Red);
            this.groupBox2.Location = new System.Drawing.Point(327, 75);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(224, 147);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Select The Second Color";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // rb1Red
            // 
            this.rb1Red.AutoSize = true;
            this.rb1Red.Location = new System.Drawing.Point(7, 32);
            this.rb1Red.Name = "rb1Red";
            this.rb1Red.Size = new System.Drawing.Size(45, 17);
            this.rb1Red.TabIndex = 0;
            this.rb1Red.TabStop = true;
            this.rb1Red.Text = "Red";
            this.rb1Red.UseVisualStyleBackColor = true;
            // 
            // rb1Blue
            // 
            this.rb1Blue.AutoSize = true;
            this.rb1Blue.Location = new System.Drawing.Point(7, 55);
            this.rb1Blue.Name = "rb1Blue";
            this.rb1Blue.Size = new System.Drawing.Size(46, 17);
            this.rb1Blue.TabIndex = 0;
            this.rb1Blue.TabStop = true;
            this.rb1Blue.Text = "Blue";
            this.rb1Blue.UseVisualStyleBackColor = true;
            // 
            // rb1Yellow
            // 
            this.rb1Yellow.AutoSize = true;
            this.rb1Yellow.Location = new System.Drawing.Point(7, 78);
            this.rb1Yellow.Name = "rb1Yellow";
            this.rb1Yellow.Size = new System.Drawing.Size(56, 17);
            this.rb1Yellow.TabIndex = 0;
            this.rb1Yellow.TabStop = true;
            this.rb1Yellow.Text = "Yellow";
            this.rb1Yellow.UseVisualStyleBackColor = true;
            // 
            // rb2Red
            // 
            this.rb2Red.AutoSize = true;
            this.rb2Red.Location = new System.Drawing.Point(6, 32);
            this.rb2Red.Name = "rb2Red";
            this.rb2Red.Size = new System.Drawing.Size(45, 17);
            this.rb2Red.TabIndex = 0;
            this.rb2Red.TabStop = true;
            this.rb2Red.Text = "Red";
            this.rb2Red.UseVisualStyleBackColor = true;
            // 
            // rb2Blue
            // 
            this.rb2Blue.AutoSize = true;
            this.rb2Blue.Location = new System.Drawing.Point(6, 55);
            this.rb2Blue.Name = "rb2Blue";
            this.rb2Blue.Size = new System.Drawing.Size(46, 17);
            this.rb2Blue.TabIndex = 0;
            this.rb2Blue.TabStop = true;
            this.rb2Blue.Text = "Blue";
            this.rb2Blue.UseVisualStyleBackColor = true;
            // 
            // rb2Yellow
            // 
            this.rb2Yellow.AutoCheck = false;
            this.rb2Yellow.AutoSize = true;
            this.rb2Yellow.Location = new System.Drawing.Point(6, 78);
            this.rb2Yellow.Name = "rb2Yellow";
            this.rb2Yellow.Size = new System.Drawing.Size(56, 17);
            this.rb2Yellow.TabIndex = 0;
            this.rb2Yellow.TabStop = true;
            this.rb2Yellow.Text = "Yellow";
            this.rb2Yellow.UseVisualStyleBackColor = true;
            // 
            // btnMix
            // 
            this.btnMix.Location = new System.Drawing.Point(175, 242);
            this.btnMix.Name = "btnMix";
            this.btnMix.Size = new System.Drawing.Size(75, 23);
            this.btnMix.TabIndex = 1;
            this.btnMix.Text = "Mix";
            this.btnMix.UseVisualStyleBackColor = true;
            this.btnMix.Click += new System.EventHandler(this.btnMix_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(327, 242);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // frmMix
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 415);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnMix);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmMix";
            this.Text = "PRK5_Q1_35526734 (Color Mixer)";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rb1Yellow;
        private System.Windows.Forms.RadioButton rb1Blue;
        private System.Windows.Forms.RadioButton rb1Red;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rb2Yellow;
        private System.Windows.Forms.RadioButton rb2Blue;
        private System.Windows.Forms.RadioButton rb2Red;
        private System.Windows.Forms.Button btnMix;
        private System.Windows.Forms.Button button2;
    }
}

