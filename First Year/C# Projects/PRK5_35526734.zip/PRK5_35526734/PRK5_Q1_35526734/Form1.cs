﻿//Niel Nortier PRK5_Q1_35526734
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK5_Q1_35526734
{
    public partial class frmMix : Form
    {
        public frmMix()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnMix_Click(object sender, EventArgs e)
        {
            if (rb1Red.Checked) //Using First Red
            {
                if (rb2Red.Checked)
                {
                    //Red
                    this.BackColor = Color.Red;

                } else if (rb2Blue.Checked)
                {
                    //Purple
                    this.BackColor = Color.Purple;
                }
                else if (rb2Yellow.Checked)
                {
                    //Orange
                    this.BackColor = Color.Orange;
                }
            } else if (rb1Blue.Checked) // Using Blue First
            {
                if (rb2Red.Checked)
                {
                    //Purple
                    this.BackColor = Color.Purple;

                }
                else if (rb2Blue.Checked)
                {
                    //Blue
                    this.BackColor = Color.Blue;
                }
                else if (rb2Yellow.Checked)
                {
                    //Green
                    this.BackColor = Color.Green;
                }
            }else if (rb1Yellow.Checked) // Using Yellow First
            {
                if (rb2Red.Checked)
                {
                    //Orange
                    this.BackColor = Color.Orange;
                }
                else if (rb2Blue.Checked)
                {
                    //Green
                    this.BackColor = Color.Green;
                }
                else if (rb2Yellow.Checked)
                {
                    //Yellow
                    this.BackColor = Color.Yellow;
                }
            }
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
