﻿//Niel Nortier 35526734 PRK4 Q3
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK4_Q3_35526734
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private bool PalindromeCheck(string sPalindrome)  //method to check for palindome
        {
            string sReverse = "";
            for (int i = sPalindrome.Length - 1; i >= 0; i--)  
            {
                sReverse += sPalindrome[i].ToString();
            }
            if (sReverse == sPalindrome)
            {
               return true;
            }
            else
            {
                return false;
            }
        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            //Variables
            string sFirst, sSecond;
            bool bFlag;


            //Input
            sFirst = txtFirst.Text;
            sSecond = txtSecond.Text;


            
            if (PalindromeCheck(sFirst) && PalindromeCheck(sSecond)) //Checking if woth strings are palindromes
            {
                bFlag = true;
            }
            else { bFlag = false;}
            

            if (bFlag && (sFirst.ToUpper() == sSecond.ToUpper())) //Check if both strings are the same
            {
                lblOut.Text = "The two words are the same palindorme";
            }
            else if(bFlag)
            {
                lblOut.Text = "Both words are a palindrome";
            }
            else if (PalindromeCheck(sFirst))
            {
                lblOut.Text = "Only the first word is a palindrome";
            }
            else
            {
                lblOut.Text = "Only the second word is a palindrome";
            }

            


        }
    }
}
