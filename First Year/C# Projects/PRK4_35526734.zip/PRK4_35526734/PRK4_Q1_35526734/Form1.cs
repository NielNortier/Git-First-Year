﻿//Niel Nortier 35526734 PRK4 Q1

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK_Q1_35526734
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {

            //Variabled
            const double MULTI = 9.80;
            double dWeight, dMass;

            //Input
            dMass = double.Parse(txtMass.Text);
            dWeight = dMass * MULTI;


            //Decision to decide where Weight Interval lies
            if(dWeight > 1000.00)
                {
                    lblOut.BackColor = Color.Red;
                    lblOut.Text = "It is too heavy.";
                }
            else if (dWeight < 10)
                {
                    lblOut.BackColor = Color.Blue;
                    lblOut.Text = "It is too light.";
                }
            else
                {
                    lblOut.BackColor = Color.Green;
                    lblOut.Text = "The weight is " + dWeight.ToString();
                }

        }
    }
}
