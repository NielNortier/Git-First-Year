﻿//Niel Nortier 35526734 PRK4 Q2
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK4_Q2_35526734
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            //Variables
            const double RESIDANCE_FEES = 2000.00;
            double dReceived, dFood , dTotal;

            //Input
            dReceived = double.Parse(txtReceived.Text);
            dFood = double.Parse(txtFood.Text);

            //Calculation of spending money
            dTotal = dReceived - (RESIDANCE_FEES + dFood);
            if (dTotal < 0)
                {
                lblOut.Text = "R2000 will be subtracted for residance fees\n\nYou will not have enough money for the month \nYour total will be: R" + dTotal.ToString();
                }
            else if (dTotal == 0.00)
                {
                lblOut.Text = "R2000 will be subtracted for residance fees\n\nYou will have no spending money";
                }
            else
            {
                lblOut.Text = "R2000 will be subtracted for residance fees\n\nYou will have: R" + dTotal.ToString() + " Spending Money";
            }
        }
    }
}
