﻿namespace PRK4_Q2_35526734
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblReceived = new System.Windows.Forms.Label();
            this.txtReceived = new System.Windows.Forms.TextBox();
            this.lblOut = new System.Windows.Forms.Label();
            this.txtFood = new System.Windows.Forms.TextBox();
            this.lblFood = new System.Windows.Forms.Label();
            this.btnCal = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student Budget Calculator";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnCal);
            this.groupBox1.Controls.Add(this.txtFood);
            this.groupBox1.Controls.Add(this.txtReceived);
            this.groupBox1.Controls.Add(this.lblFood);
            this.groupBox1.Controls.Add(this.lblOut);
            this.groupBox1.Controls.Add(this.lblReceived);
            this.groupBox1.Location = new System.Drawing.Point(15, 42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(266, 158);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Enter Details Here";
            // 
            // lblReceived
            // 
            this.lblReceived.AutoSize = true;
            this.lblReceived.Location = new System.Drawing.Point(6, 16);
            this.lblReceived.Name = "lblReceived";
            this.lblReceived.Size = new System.Drawing.Size(114, 13);
            this.lblReceived.TabIndex = 0;
            this.lblReceived.Text = "Enter amount recieved";
            // 
            // txtReceived
            // 
            this.txtReceived.Location = new System.Drawing.Point(158, 19);
            this.txtReceived.Name = "txtReceived";
            this.txtReceived.Size = new System.Drawing.Size(100, 20);
            this.txtReceived.TabIndex = 1;
            // 
            // lblOut
            // 
            this.lblOut.AutoSize = true;
            this.lblOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOut.Location = new System.Drawing.Point(9, 108);
            this.lblOut.Name = "lblOut";
            this.lblOut.Size = new System.Drawing.Size(163, 15);
            this.lblOut.TabIndex = 0;
            this.lblOut.Text = "Spending Money Wil Show Here";
            this.lblOut.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtFood
            // 
            this.txtFood.Location = new System.Drawing.Point(158, 45);
            this.txtFood.Name = "txtFood";
            this.txtFood.Size = new System.Drawing.Size(100, 20);
            this.txtFood.TabIndex = 1;
            // 
            // lblFood
            // 
            this.lblFood.AutoSize = true;
            this.lblFood.Location = new System.Drawing.Point(6, 45);
            this.lblFood.Name = "lblFood";
            this.lblFood.Size = new System.Drawing.Size(109, 13);
            this.lblFood.TabIndex = 0;
            this.lblFood.Text = "Enter amount for food";
            // 
            // btnCal
            // 
            this.btnCal.Location = new System.Drawing.Point(9, 71);
            this.btnCal.Name = "btnCal";
            this.btnCal.Size = new System.Drawing.Size(249, 23);
            this.btnCal.TabIndex = 2;
            this.btnCal.Text = "Calculate Spending Money";
            this.btnCal.UseVisualStyleBackColor = true;
            this.btnCal.Click += new System.EventHandler(this.btnCal_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(297, 253);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Q2_35526734 Student Budget";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnCal;
        private System.Windows.Forms.TextBox txtFood;
        private System.Windows.Forms.TextBox txtReceived;
        private System.Windows.Forms.Label lblFood;
        private System.Windows.Forms.Label lblOut;
        private System.Windows.Forms.Label lblReceived;
    }
}

