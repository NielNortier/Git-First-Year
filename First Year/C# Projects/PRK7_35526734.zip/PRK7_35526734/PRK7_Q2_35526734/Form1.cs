﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK7_Q2_35526734
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int iFirst, iSecond, iRand;

            if ((int.TryParse(textBox1.Text, out iFirst)) || int.TryParse(textBox1.Text, out iSecond))
            {
                iFirst = int.Parse(textBox1.Text);
                iSecond = int.Parse(textBox2.Text);

                
            }
            else MessageBox.Show("Enter valid data type");

        }
    }
}
