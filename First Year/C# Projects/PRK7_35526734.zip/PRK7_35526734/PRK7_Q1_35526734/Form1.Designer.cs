﻿namespace PRK7_Q1_35526734
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWeight = new System.Windows.Forms.Label();
            this.tbWeight = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbCycling = new System.Windows.Forms.RadioButton();
            this.rbRunning = new System.Windows.Forms.RadioButton();
            this.rbrowing = new System.Windows.Forms.RadioButton();
            this.btnCal = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lbOut = new System.Windows.Forms.ListBox();
            this.lblKg = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.Location = new System.Drawing.Point(48, 39);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(47, 13);
            this.lblWeight.TabIndex = 0;
            this.lblWeight.Text = "Weight: ";
            // 
            // tbWeight
            // 
            this.tbWeight.Location = new System.Drawing.Point(115, 39);
            this.tbWeight.Name = "tbWeight";
            this.tbWeight.Size = new System.Drawing.Size(100, 20);
            this.tbWeight.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbrowing);
            this.groupBox1.Controls.Add(this.rbRunning);
            this.groupBox1.Controls.Add(this.rbCycling);
            this.groupBox1.Location = new System.Drawing.Point(324, 82);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(136, 124);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " ";
            // 
            // rbCycling
            // 
            this.rbCycling.AutoSize = true;
            this.rbCycling.Location = new System.Drawing.Point(27, 19);
            this.rbCycling.Name = "rbCycling";
            this.rbCycling.Size = new System.Drawing.Size(59, 17);
            this.rbCycling.TabIndex = 0;
            this.rbCycling.TabStop = true;
            this.rbCycling.Text = "Cycling";
            this.rbCycling.UseVisualStyleBackColor = true;
            // 
            // rbRunning
            // 
            this.rbRunning.AutoSize = true;
            this.rbRunning.Location = new System.Drawing.Point(27, 43);
            this.rbRunning.Name = "rbRunning";
            this.rbRunning.Size = new System.Drawing.Size(65, 17);
            this.rbRunning.TabIndex = 0;
            this.rbRunning.TabStop = true;
            this.rbRunning.Text = "Running";
            this.rbRunning.UseVisualStyleBackColor = true;
            // 
            // rbrowing
            // 
            this.rbrowing.AutoSize = true;
            this.rbrowing.Location = new System.Drawing.Point(27, 66);
            this.rbrowing.Name = "rbrowing";
            this.rbrowing.Size = new System.Drawing.Size(61, 17);
            this.rbrowing.TabIndex = 0;
            this.rbrowing.TabStop = true;
            this.rbrowing.Text = "Rowing";
            this.rbrowing.UseVisualStyleBackColor = true;
            // 
            // btnCal
            // 
            this.btnCal.Location = new System.Drawing.Point(324, 255);
            this.btnCal.Name = "btnCal";
            this.btnCal.Size = new System.Drawing.Size(136, 36);
            this.btnCal.TabIndex = 3;
            this.btnCal.Text = "Show Calories Burnt";
            this.btnCal.UseVisualStyleBackColor = true;
            this.btnCal.Click += new System.EventHandler(this.btnCal_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(324, 297);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(136, 36);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lbOut
            // 
            this.lbOut.FormattingEnabled = true;
            this.lbOut.Location = new System.Drawing.Point(51, 82);
            this.lbOut.Name = "lbOut";
            this.lbOut.Size = new System.Drawing.Size(208, 238);
            this.lbOut.TabIndex = 4;
            // 
            // lblKg
            // 
            this.lblKg.AutoSize = true;
            this.lblKg.Location = new System.Drawing.Point(240, 46);
            this.lblKg.Name = "lblKg";
            this.lblKg.Size = new System.Drawing.Size(19, 13);
            this.lblKg.TabIndex = 0;
            this.lblKg.Text = "kg";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 504);
            this.Controls.Add(this.lbOut);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCal);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tbWeight);
            this.Controls.Add(this.lblKg);
            this.Controls.Add(this.lblWeight);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.TextBox tbWeight;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbrowing;
        private System.Windows.Forms.RadioButton rbRunning;
        private System.Windows.Forms.RadioButton rbCycling;
        private System.Windows.Forms.Button btnCal;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.ListBox lbOut;
        private System.Windows.Forms.Label lblKg;
    }
}

