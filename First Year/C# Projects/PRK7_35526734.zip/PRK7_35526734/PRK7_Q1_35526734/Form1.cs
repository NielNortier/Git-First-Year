﻿//Niel Nortier 35526734
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK7_Q1_35526734
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            double dWeight, dFinal, dRatio;
            dFinal = 0;
            dRatio = 0;
            if (double.TryParse(tbWeight.Text, out dWeight))  //Input
            { 
                dWeight = double.Parse(tbWeight.Text);

                if (rbCycling.Checked)    //Checking ratios
                {
                    dRatio = 1.0;
                }else if (rbRunning.Checked)
                {
                    dRatio = 1.2;
                }else if (rbrowing.Checked)
                {
                    dRatio = 1.5;
                }
                else
                {
                    MessageBox.Show("Please check type of exercise");
                    
                }


                lbOut.Items.Add("Minutes\tCalories");     //Output
                for (int i = 1; i < 6; i++)
                {
                    dFinal = dFinal + (dWeight*dRatio);
                    lbOut.Items.Add(((i*10).ToString()) + "\t" +dFinal.ToString());
                }


            }
            else
            {
                MessageBox.Show("enter valid weight");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
