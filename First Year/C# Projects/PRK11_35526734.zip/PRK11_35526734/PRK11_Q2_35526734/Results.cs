﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Niel Nortier 35526734

namespace PRK11_Q2_35526734
{
    public partial class Results : Form
    {
        public Results()
        {
            InitializeComponent();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            lbReview.Items.Clear();
            this.Close();
           

        }


        public void DisplayData(string sText, string sSize, double dPrice)
        {
            lbReview.Items.Add("Your text you have chosen is: " + sText);
            lbReview.Items.Add("You have chosen the size: " + sSize);
            lbReview.Items.Add("The total of your custom Mug will be: " + dPrice.ToString("c"));
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            lbReview.Items.Clear();
            this.Close();
        }
    }
}
