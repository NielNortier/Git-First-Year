﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Niel Nortier 35526734

namespace PRK11_Q2_35526734
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReview_Click(object sender, EventArgs e)
        {
            string sMug = tbMug.Text;

            Results DisplayResults = new Results();
            DisplayResults.Show();

            DisplayResults.DisplayData(sMug, getSize(), CalcPrice());



        }

        public string getSize()
        {
            string sSize = "";
            if (rbSmall.Checked)
            {
                sSize = "Small";
            }
            else if (rbMedium.Checked)
            {
                sSize = "Medium";
            }
            else if (rbLarge.Checked)
            {
                sSize = "Large";
            }
            else MessageBox.Show("Please Select a valid Size");

            return sSize;
        }

        private double CalcPrice()
        {
            double dTotal = 0;
            int iWords = (tbMug.Text).Length;
            switch (getSize())
            {
                case "Small": dTotal = iWords * 1.5;
                    break;
                case "Medium": dTotal = iWords * 2.5;
                    break;
                case "Large": dTotal = iWords * 3.5;
                    break;
                default: MessageBox.Show("An error has occured, Please retry");
                    break;
            }

            return dTotal;
        }


    }
}
