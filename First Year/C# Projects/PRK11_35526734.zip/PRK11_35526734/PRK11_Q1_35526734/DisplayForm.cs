﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Niel Nortier 35526734

namespace PRK11_Q1_35526734
{
    public partial class DisplayForm : Form
    {
        public DisplayForm()
        {
            InitializeComponent();
        }

        private void DisplayForm_Load(object sender, EventArgs e)
        {

        }

        public void DisplayCalc(double dDorm, double dMeal)
        {
            double dTotal;
            dTotal = dDorm + dMeal;

            lblDorm.Text = "Dormitory: " + dDorm.ToString("c") + " per semester";
            lblMeal.Text = "Meal Plan: " + dMeal.ToString("c") + " per semester";
            lblTotal.Text = "Total: " + dTotal.ToString("c") + " per semester";
        }

        private void lblDorm_Click(object sender, EventArgs e)
        {

        }
    }
}
