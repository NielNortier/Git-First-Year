﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Niel Nortier 35526734

namespace PRK11_Q1_35526734
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {

            double dMeal = 0;
            double dDorm = 0;


            DisplayForm DisplayResults = new DisplayForm();
            DisplayResults.Show();

            switch (lbDorm.SelectedIndex)
            {
                case 0: dDorm = 1500;
                        break;
                case 1: dDorm = 1600;
                    break;
                case 2: dDorm = 1800;
                    break;
                case 3: dDorm = 2500;
                    break;
            }

            switch (lbMeal.SelectedIndex)
            {
                case 0: dMeal = 600;
                    break;
                case 1: dMeal = 1200;
                    break;
                case 2: dMeal = 1700;
                    break;
            }

            DisplayResults.DisplayCalc(dDorm, dMeal);



            
        }
    }
}
