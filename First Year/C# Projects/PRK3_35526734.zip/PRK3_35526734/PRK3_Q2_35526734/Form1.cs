﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK3_Q2_35526734
{
    public partial class Form1 : Form
    {
        string sID, sGender;
        int iValid;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            gbID.ForeColor = Color.Red;
            sID = tbID.Text;
            string sDate = sID.Substring(0,6);
            int iDate = int.Parse(sID.Substring(6, 4));
            if (iDate<5000)
            {
                sGender = "Female";
            }
            else
            {
                sGender = "Male";
            }
            lblOut.Text = "ID Number: " + sID + "\nGender: " + sGender + "\n" + "Date: " + sDate; 

            
            
            
        }
    }
}
