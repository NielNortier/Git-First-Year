﻿// Niel Nortier 35526734 PRK3 Q1
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRK3_Q3._1_35526734
{
    public partial class Form1 : Form
    {
        double dGallonsPaint, dHoursLabour, dPaintcost, dLabourCharge, dTotal, dWallSpace,dGallonPrice;
        int yetta;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Begin output text
            lblOut.Text = "The Number of gallons of paint required: \nThe hours of labour required: \nThe cost of the paint: \nThe labour charges: \nThe total cost of the paint job: \n";

        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            //Conversion of variables
            dWallSpace = Convert.ToDouble(txtSpace.Text);
            dGallonPrice = Convert.ToDouble(txtPrice.Text);
            //Process of data for output
            dGallonsPaint = dWallSpace / 115;
            dHoursLabour = dGallonsPaint * 8;
            dPaintcost = dGallonPrice * dGallonsPaint;
            dLabourCharge = dHoursLabour * 20;
            dTotal = dPaintcost + dLabourCharge;










            //Output of data
            lblOut.Text = "The Number of gallons of paint required: R" +Convert.ToString(Math.Round(dGallonsPaint,2)) + "\nThe hours of labour required: R" + Convert.ToString(Math.Round(dHoursLabour, 2)) + " \nThe cost of the paint: R" + Convert.ToString(Math.Round(dPaintcost, 2)) + "\nThe labour charges: R" + Convert.ToString(Math.Round(dLabourCharge, 2)) + "\nThe total cost of the paint job: R" + Convert.ToString(Math.Round(dTotal, 2));


        }
    }
}
